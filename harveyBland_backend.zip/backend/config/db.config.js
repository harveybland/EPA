module.exports = {
    host: "ap-sp-proj-c.chwmwhavjzga.eu-west-2.rds.amazonaws.com",
    user: "admin",
    password: "Yh2RCmGWfXFxwZv68J4m",
    database: "webform",
    dialect: 'mysql'
}
